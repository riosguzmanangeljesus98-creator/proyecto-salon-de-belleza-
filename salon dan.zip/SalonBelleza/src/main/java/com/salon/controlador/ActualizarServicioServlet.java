package com.salon.controlador;

import Servicio.Servicio;
import com.salon.dao.ServicioDAO;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ActualizarServicioServlet")
public class ActualizarServicioServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        Servicio servicio = new Servicio();

        servicio.setIdServicio(
                Integer.parseInt(
                        request.getParameter("id"))
        );

        servicio.setNombre(
                request.getParameter("nombre")
        );

        servicio.setDescripcion(
                request.getParameter("descripcion")
        );

        servicio.setPrecio(
                Double.parseDouble(
                        request.getParameter("precio"))
        );

        servicio.setDuracion(
                Integer.parseInt(
                        request.getParameter("duracion"))
        );

        ServicioDAO dao = new ServicioDAO();

        dao.actualizarServicio(servicio);

        response.sendRedirect("servicios.jsp");
    }
}