package com.salon.controlador;

import com.salon.dao.ServicioDAO;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/EliminarServicioServlet")
public class EliminarServicioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int idServicio = Integer.parseInt(
                request.getParameter("id")
        );

        ServicioDAO dao = new ServicioDAO();

        dao.eliminarServicio(idServicio);

        response.sendRedirect("servicios.jsp");
    }
}