package com.salon.controlador;

import Servicio.Servicio;
import com.salon.dao.ServicioDAO;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ServicioServlet")
public class ServicioServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");

        double precio = Double.parseDouble(
                request.getParameter("precio")
        );

        int duracion = Integer.parseInt(
                request.getParameter("duracion")
        );

        Servicio servicio = new Servicio();

        servicio.setNombre(nombre);
        servicio.setDescripcion(descripcion);
        servicio.setPrecio(precio);
        servicio.setDuracion(duracion);

        ServicioDAO dao = new ServicioDAO();

        dao.guardarServicio(servicio);

        response.sendRedirect("servicios.jsp");
    }
}