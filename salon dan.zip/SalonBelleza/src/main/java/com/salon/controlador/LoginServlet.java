package com.salon.controlador;

import Usuario.Usuario;
import com.salon.dao.UsuarioDAO;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String correo = request.getParameter("correo");
        String password = request.getParameter("password");

        UsuarioDAO dao = new UsuarioDAO();

        Usuario usuario = dao.login(correo, password);

        if (usuario != null) {

            HttpSession sesion = request.getSession();

            sesion.setAttribute("usuario", usuario);

            response.sendRedirect("dashboard.jsp");

        } else {

            response.getWriter().println(
                    "<h1>Correo o contraseña incorrectos</h1>" +
                    "<br><a href='login.jsp'>Volver</a>"
            );

        }
    }
}