package com.salon.controlador;

import Usuario.Usuario;
import com.salon.dao.UsuarioDAO;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/RegistroServlet")
public class RegistroServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        Usuario usuario = new Usuario();

        usuario.setNombre(
                request.getParameter("nombre")
        );

        usuario.setCorreo(
                request.getParameter("correo")
        );

        usuario.setPassword(
                request.getParameter("password")
        );

        usuario.setRol(
                request.getParameter("rol")
        );

        UsuarioDAO dao = new UsuarioDAO();

        if (dao.registrarUsuario(usuario)) {

            response.sendRedirect("login.jsp");

        } else {

            response.getWriter().println(
                    "<h1>Error al registrar usuario</h1>"
            );

        }
    }
}