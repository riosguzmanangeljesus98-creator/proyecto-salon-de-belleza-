package com.salon.controlador;

import Cita.Cita;
import com.salon.dao.CitaDAO;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CitaServlet")
public class CitaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        Cita cita = new Cita();

        cita.setIdUsuario(
                Integer.parseInt(
                        request.getParameter("idUsuario"))
        );

        cita.setIdServicio(
                Integer.parseInt(
                        request.getParameter("idServicio"))
        );

        cita.setFecha(
                request.getParameter("fecha")
        );

        cita.setHora(
                request.getParameter("hora")
        );

        cita.setEstado(
                request.getParameter("estado")
        );

        CitaDAO dao = new CitaDAO();

        dao.guardarCita(cita);

        response.sendRedirect("citas.jsp");
    }
}