package com.salon.dao;

import Cita.Cita;

public class TestCita {

    public static void main(String[] args) {

        Cita cita = new Cita();

        cita.setIdUsuario(1);
        cita.setIdServicio(1);
        cita.setFecha("2026-11-20");
        cita.setHora("12:00:00");
        cita.setEstado("Pendiente");

        CitaDAO dao = new CitaDAO();

        if(dao.guardarCita(cita)){

            System.out.println("Cita guardada");

        }else{

            System.out.println("Error al guardar cita");

        }

    }
}