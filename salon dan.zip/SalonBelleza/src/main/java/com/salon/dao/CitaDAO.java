package com.salon.dao;

import Cita.Cita;
import com.salon.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CitaDAO {

    public boolean guardarCita(Cita cita){

        String sql = "INSERT INTO citas(id_usuario,id_servicio,fecha,hora,estado) VALUES(?,?,?,?,?)";

        try{

            Connection con = Conexion.getConexion();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, cita.getIdUsuario());
            ps.setInt(2, cita.getIdServicio());
            ps.setString(3, cita.getFecha());
            ps.setString(4, cita.getHora());
            ps.setString(5, cita.getEstado());

            ps.executeUpdate();

            return true;

        }catch(Exception e){

            e.printStackTrace();
            return false;

        }
    }

    public ArrayList<Cita> listarCitas(){

        ArrayList<Cita> lista = new ArrayList<>();

        String sql = "SELECT * FROM citas";

        try{

            Connection con = Conexion.getConexion();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                Cita cita = new Cita();

                cita.setIdCita(rs.getInt("id_cita"));
                cita.setIdUsuario(rs.getInt("id_usuario"));
                cita.setIdServicio(rs.getInt("id_servicio"));
                cita.setFecha(rs.getString("fecha"));
                cita.setHora(rs.getString("hora"));
                cita.setEstado(rs.getString("estado"));

                lista.add(cita);

            }

        }catch(Exception e){

            e.printStackTrace();

        }

        return lista;
    }
}