package com.salon.dao;

import Servicio.Servicio;

public class TestServicio {

    public static void main(String[] args) {

        Servicio servicio = new Servicio();

        servicio.setNombre("Corte de Cabello");
        servicio.setDescripcion("Corte para dama o caballero");
        servicio.setPrecio(150);
        servicio.setDuracion(30);

        ServicioDAO dao = new ServicioDAO();

        if(dao.guardarServicio(servicio)){

            System.out.println("Servicio guardado");

        }else{

            System.out.println("Error");

        }

    }
}