package com.salon.dao;

import Servicio.Servicio;
import com.salon.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ServicioDAO {

    public boolean guardarServicio(Servicio servicio) {

        String sql = "INSERT INTO servicios(nombre, descripcion, precio, duracion) VALUES(?,?,?,?)";

        try {

            Connection con = Conexion.getConexion();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, servicio.getNombre());
            ps.setString(2, servicio.getDescripcion());
            ps.setDouble(3, servicio.getPrecio());
            ps.setInt(4, servicio.getDuracion());

            ps.executeUpdate();

            return true;

        } catch (Exception e) {

            e.printStackTrace();
            return false;

        }
    }

    public ArrayList<Servicio> listarServicios() {

        ArrayList<Servicio> lista = new ArrayList<>();

        String sql = "SELECT * FROM servicios";

        try {

            Connection con = Conexion.getConexion();

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Servicio servicio = new Servicio();

                servicio.setIdServicio(rs.getInt("id_servicio"));
                servicio.setNombre(rs.getString("nombre"));
                servicio.setDescripcion(rs.getString("descripcion"));
                servicio.setPrecio(rs.getDouble("precio"));
                servicio.setDuracion(rs.getInt("duracion"));

                lista.add(servicio);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return lista;
    }

    public Servicio buscarServicio(int idServicio) {

        Servicio servicio = null;

        String sql = "SELECT * FROM servicios WHERE id_servicio=?";

        try {

            Connection con = Conexion.getConexion();

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, idServicio);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                servicio = new Servicio();

                servicio.setIdServicio(rs.getInt("id_servicio"));
                servicio.setNombre(rs.getString("nombre"));
                servicio.setDescripcion(rs.getString("descripcion"));
                servicio.setPrecio(rs.getDouble("precio"));
                servicio.setDuracion(rs.getInt("duracion"));

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return servicio;
    }

public boolean actualizarServicio(Servicio servicio) {

    String sql = "UPDATE servicios SET nombre=?, descripcion=?, precio=?, duracion=? WHERE id_servicio=?";

    try {

        Connection con = Conexion.getConexion();

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setString(1, servicio.getNombre());
        ps.setString(2, servicio.getDescripcion());
        ps.setDouble(3, servicio.getPrecio());
        ps.setInt(4, servicio.getDuracion());
        ps.setInt(5, servicio.getIdServicio());

        ps.executeUpdate();

        return true;

    } catch (Exception e) {

        e.printStackTrace();
        return false;

    }
}

public boolean eliminarServicio(int idServicio) {

    String sql = "DELETE FROM servicios WHERE id_servicio=?";

    try {

        Connection con = Conexion.getConexion();

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setInt(1, idServicio);

        ps.executeUpdate();

        return true;

    } catch (Exception e) {

        e.printStackTrace();
        return false;

    }
}
}