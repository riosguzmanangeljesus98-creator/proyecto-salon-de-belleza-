import Usuario.Usuario;
import com.salon.dao.UsuarioDAO;

public class TestUsuario {

    public static void main(String[] args) {

        UsuarioDAO dao = new UsuarioDAO();

        Usuario usuario = dao.login(
                "angel@gmail.com",
                "123456"
        );

        if(usuario != null){

            System.out.println("Login correcto");
            System.out.println("Bienvenido: " + usuario.getNombre());

        }else{

            System.out.println("Login incorrecto");

        }

    }

}