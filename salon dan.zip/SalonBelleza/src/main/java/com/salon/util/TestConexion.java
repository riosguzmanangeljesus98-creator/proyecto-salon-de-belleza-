package com.salon.util;

public class TestConexion {

    public static void main(String[] args) {

        Conexion.getConexion();

    }

}