<%@ page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="Usuario.Usuario" %>

<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");

    if(usuario == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Panel Principal</title>

    <style>

        body{
            font-family: Arial, sans-serif;
            margin:0;
            background:#f4f6f9;
        }

        .header{
            background:#007bff;
            color:white;
            text-align:center;
            padding:25px;
        }

        .contenedor{
            width:90%;
            margin:auto;
            margin-top:30px;
        }

        .tarjetas{
            display:flex;
            justify-content:center;
            gap:20px;
            flex-wrap:wrap;
        }

        .tarjeta{
            width:280px;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px #ccc;
            text-align:center;
        }

        .btn{
            display:inline-block;
            margin-top:15px;
            padding:10px 20px;
            color:white;
            text-decoration:none;
            border-radius:5px;
            font-weight:bold;
        }

        .servicios{
            background:#28a745;
        }

        .citas{
            background:#007bff;
        }

        .salir{
            background:#dc3545;
        }

    </style>

</head>

<body>

    <div class="header">

        <h1>Sistema de Gestión de Citas</h1>

        <h2>
            Bienvenido <%= usuario.getNombre() %>
        </h2>

    </div>

    <div class="contenedor">

        <div class="tarjetas">

            <div class="tarjeta">

                <h3>Servicios</h3>

                <p>
                    Registrar y administrar servicios.
                </p>

                <a href="servicios.jsp"
                   class="btn servicios">
                    Gestionar Servicios
                </a>

            </div>

            <div class="tarjeta">

                <h3>Citas</h3>

                <p>
                    Registrar y consultar citas.
                </p>

                <a href="citas.jsp"
                   class="btn citas">
                    Gestionar Citas
                </a>

            </div>

            <div class="tarjeta">

                <h3>Salir</h3>

                <p>
                    Cerrar sesión del sistema.
                </p>

                <a href="LogoutServlet"
                   class="btn salir">
                    Cerrar Sesión
                </a>

            </div>

        </div>

    </div>

</body>
</html>
