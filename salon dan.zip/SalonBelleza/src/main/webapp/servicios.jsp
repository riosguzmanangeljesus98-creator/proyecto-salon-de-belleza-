<%@page import="java.util.ArrayList"%>
<%@page import="Servicio.Servicio"%>
<%@page import="com.salon.dao.ServicioDAO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    ServicioDAO dao = new ServicioDAO();
    ArrayList<Servicio> lista = dao.listarServicios();
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Servicios</title>
</head>
<body>

<h1>Gestión de Servicios</h1>

<form action="ServicioServlet" method="post">

    Nombre:
    <input type="text" name="nombre" required>

    <br><br>

    Descripción:
    <input type="text" name="descripcion" required>

    <br><br>

    Precio:
    <input type="number" step="0.01" name="precio" required>

    <br><br>

    Duración:
    <input type="number" name="duracion" required>

    <br><br>

    <button type="submit">
        Guardar Servicio
    </button>

</form>

<br><br>

<table border="1">

<tr>
    <th>ID</th>
    <th>Nombre</th>
    <th>Descripción</th>
    <th>Precio</th>
    <th>Duración</th>
</tr>

<%
for(Servicio s : lista){
%>

<tr>

    <td><%= s.getIdServicio() %></td>
    <td><%= s.getNombre() %></td>
    <td><%= s.getDescripcion() %></td>
    <td><%= s.getPrecio() %></td>
    <td><%= s.getDuracion() %></td>

</tr>

<%
}
%>

</table>

<br><br>

<a href="dashboard.jsp">
    Volver al Dashboard
</a>

</body>
</html>