<%@page import="java.util.ArrayList"%>
<%@page import="Cita.Cita"%>
<%@page import="com.salon.dao.CitaDAO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    CitaDAO dao = new CitaDAO();
    ArrayList<Cita> lista = dao.listarCitas();
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Gestión de Citas</title>

<style>

body{
    font-family: Arial;
    background:#f4f4f4;
    padding:20px;
}

.contenedor{
    width:90%;
    margin:auto;
}

.formulario{
    background:white;
    padding:20px;
    border-radius:10px;
    margin-bottom:20px;
    box-shadow:0px 0px 10px #ccc;
}

input{
    width:100%;
    padding:10px;
    margin-top:5px;
    margin-bottom:15px;
}

button{
    background:#007bff;
    color:white;
    border:none;
    padding:10px 20px;
    cursor:pointer;
}

table{
    width:100%;
    background:white;
    border-collapse:collapse;
}

th{
    background:#007bff;
    color:white;
    padding:10px;
}

td{
    border:1px solid #ddd;
    padding:10px;
    text-align:center;
}

</style>

</head>

<body>

<div class="contenedor">

<h1>Gestión de Citas</h1>

<form action="CitaServlet" method="post">

    Usuario ID:
    <input type="number" name="idUsuario" required>

    Servicio ID:
    <input type="number" name="idServicio" required>

    Fecha:
    <input type="date" name="fecha" required>

    Hora:
    <input type="time" name="hora" required>

    Estado:
    <input type="text" name="estado" value="Pendiente">

    <button type="submit">
        Guardar Cita
    </button>

</form>

<br>

<table>

<tr>
    <th>ID</th>
    <th>Usuario</th>
    <th>Servicio</th>
    <th>Fecha</th>
    <th>Hora</th>
    <th>Estado</th>
</tr>

<%
for(Cita c : lista){
%>

<tr>

    <td><%= c.getIdCita() %></td>

    <td><%= c.getIdUsuario() %></td>

    <td><%= c.getIdServicio() %></td>

    <td><%= c.getFecha() %></td>

    <td><%= c.getHora() %></td>

    <td><%= c.getEstado() %></td>

</tr>

<%
}
%>

</table>

<br><br>

<a href="dashboard.jsp">
    Volver al Dashboard
</a>

</div>

</body>
</html>