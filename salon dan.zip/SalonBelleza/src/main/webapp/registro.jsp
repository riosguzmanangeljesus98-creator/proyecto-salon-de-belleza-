<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
</head>
<body>

<h1>Registro de Usuario</h1>

<form action="RegistroServlet" method="post">

    Nombre:
    <input type="text" name="nombre" required>

    <br><br>

    Correo:
    <input type="email" name="correo" required>

    <br><br>

    Contraseña:
    <input type="password" name="password" required>

    <br><br>

    Rol:

    <select name="rol">

        <option value="ADMIN">
            ADMIN
        </option>

        <option value="CLIENTE">
            CLIENTE
        </option>

    </select>

    <br><br>

    <button type="submit">
        Registrar Usuario
    </button>

</form>

<br>

<a href="login.jsp">
    Volver al Login
</a>

</body>
</html>