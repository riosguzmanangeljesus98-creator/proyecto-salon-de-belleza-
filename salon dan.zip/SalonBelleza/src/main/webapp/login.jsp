<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login Salón de Belleza</title>
</head>
<body>

<h1>Iniciar Sesión</h1>

<form action="LoginServlet" method="post">

    <label>Correo:</label>
    <input type="email" name="correo" required>

    <br><br>

    <label>Contraseña:</label>
    <input type="password" name="password" required>

    <br><br>

    <button type="submit">
        Ingresar
    </button>

</form>

<br><br>

<a href="registro.jsp">
    Crear Usuario
</a>

</body>
</html>
