<%@page import="Servicio.Servicio"%>
<%@page import="com.salon.dao.ServicioDAO"%>

<%
    int id = Integer.parseInt(request.getParameter("id"));

    ServicioDAO dao = new ServicioDAO();

    Servicio servicio = dao.buscarServicio(id);
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editar Servicio</title>
</head>
<body>

<h1>Editar Servicio</h1>

<form action="ActualizarServicioServlet" method="post">

    <input type="hidden"
           name="id"
           value="<%= servicio.getIdServicio() %>">

    Nombre:
    <input type="text"
           name="nombre"
           value="<%= servicio.getNombre() %>">

    <br><br>

    Descripci�n:
    <input type="text"
           name="descripcion"
           value="<%= servicio.getDescripcion() %>">

    <br><br>

    Precio:
    <input type="number"
           step="0.01"
           name="precio"
           value="<%= servicio.getPrecio() %>">

    <br><br>

    Duraci�n:
    <input type="number"
           name="duracion"
           value="<%= servicio.getDuracion() %>">

    <br><br>

    <button type="submit">
        Actualizar Servicio
    </button>

</form>

</body>
</html>